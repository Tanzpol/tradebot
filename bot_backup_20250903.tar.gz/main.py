from flask import Flask, jsonify, request, Response
from binance.spot import Spot as BinanceClient
import time

from config import FLASK_SECRET, TOP_ASSETS, FEE_RATE_BNB, BNB_SAFETY
from balances import fetch_balances
from state import list_trades, add_trade, reset_all, delete_trade, get_trade

app = Flask(__name__)
app.secret_key = FLASK_SECRET

DEFAULT_SYMBOL = "BTCUSDC"

def price_public(symbol: str):
    client = BinanceClient()
    data = client.ticker_price(symbol)
    return float(data["price"])

# ---------- PAGES ----------

@app.get("/")
def index():
    return Response("""<!doctype html>
<html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TradeSRVbot — Курс, Комиссии и Сделки</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Arial,sans-serif;margin:24px}
  .row{display:flex;gap:12px;flex-wrap:wrap;align-items:center}
  .price{font-size:42px;font-weight:700}
  .muted{color:#666}
  .ok{color:#0a0}.warn{color:#b00}
  .btn{display:inline-block;padding:8px 12px;border:1px solid #333;border-radius:8px;text-decoration:none;color:#111}
  .btn.red{border-color:#b00;color:#b00}
  .btn.gray{border-color:#aaa;color:#777}
  .card{border:1px solid #ddd;border-radius:12px;padding:16px;margin-top:16px}
  table{border-collapse:collapse;width:100%}
  th,td{padding:8px;border-bottom:1px solid #eee;text-align:left}
  tr.bnb td{background:#fff8e1}
  input,select{padding:8px 10px;border:1px solid #ccc;border-radius:8px}
  .kv{display:grid;grid-template-columns:180px 1fr;gap:8px;align-items:center}
</style>
</head><body>
  <h1>TradeSRVbot</h1>

  <div class="card">
    <div class="row">
      <label for="symbol">Пара:</label>
      <select id="symbol">
        <option value="BTCUSDC" selected>BTC/USDC</option>
        <option value="BTCUSDT">BTC/USDT</option>
        <option value="BNBUSDC">BNB/USDC</option>
      </select>
      <span id="status" class="muted">Идёт подключение…</span>
    </div>
    <div class="row" style="margin-top:8px">
      <div class="price"><span id="price">—</span></div>
      <div class="muted">обновление: <span id="ts">—</span></div>
    </div>
  </div>

  <div class="card">
    <h2 style="margin:0 0 12px 0">Новая сделка</h2>
    <div class="kv">
      <div>Пара</div>
      <div>
        <select id="pair">
          <option value="BTCUSDC" selected>BTC/USDC</option>
          <option value="BTCUSDT">BTC/USDT</option>
        </select>
      </div>

      <div>Сумма (USDC)</div>
      <div><input id="amount" type="number" min="1" step="1" value="200"></div>

      <div>Проверка BNB</div>
      <div><label><input id="requireBNB" type="checkbox" checked> Не входить, если BNB не хватит на комиссии</label></div>

      <div>Итог проверок</div>
      <div><span id="feeResult" class="muted">—</span></div>

      <div></div>
      <div class="row" style="gap:8px">
        <a class="btn" href="#" id="btnCreate">Создать сделку</a>
        <a class="btn" href="#" id="btnCreateGrid">Создать сетку 30/30/40</a>
        <span id="createHint" class="muted"></span>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="row" style="justify-content:space-between;width:100%">
      <h2 style="margin:0">Активы (топ-5)</h2>
      <div class="row" style="gap:8px">
        <div class="muted">Всего активов: <span id="assetsCount">—</span></div>
        <div class="muted">USDC свободно: <span id="usdcFree">—</span></div>
        <a href="/assets" class="btn">Мои активы</a>
      </div>
    </div>
    <div id="balancesWrap" class="muted" style="margin-top:8px">Загрузка…</div>
  </div>

  <div class="card">
    <div class="row" style="justify-content:space-between;width:100%">
      <h2 style="margin:0">Сделки</h2>
      <a class="btn red" href="#" id="btnReset">Сбросить всё</a>
    </div>
    <div id="tradesWrap" class="muted" style="margin-top:8px">Загрузка…</div>
  </div>

<script>
  const priceEl=document.getElementById('price');
  const tsEl=document.getElementById('ts');
  const statusEl=document.getElementById('status');
  const sel=document.getElementById('symbol');

  const balancesWrap=document.getElementById('balancesWrap');
  const assetsCountEl=document.getElementById('assetsCount');
  const usdcFreeEl=document.getElementById('usdcFree');

  const pairEl=document.getElementById('pair');
  const amountEl=document.getElementById('amount');
  const requireBNBEl=document.getElementById('requireBNB');
  const feeResult=document.getElementById('feeResult');
  const btnCreate=document.getElementById('btnCreate');
  const btnCreateGrid=document.getElementById('btnCreateGrid');
  const createHint=document.getElementById('createHint');

  const tradesWrap=document.getElementById('tradesWrap');
  const btnReset=document.getElementById('btnReset');

  let last=null, timerPrice=null, timerBal=null;
  let lastFee = {enough:false,enough_usdc:false};

  function fmt(n,d=2){ return Number(n).toLocaleString('ru-RU',{minimumFractionDigits:d,maximumFractionDigits:d}); }
  function now(){ return new Date().toLocaleTimeString('ru-RU'); }

  async function pollPrice(){
    const symbol = sel.value;
    try{
      const r = await fetch(`/api/price?symbol=${encodeURIComponent(symbol)}`,{cache:'no-store'});
      const j = await r.json();
      if(!r.ok) throw new Error(j.error||('HTTP '+r.status));
      const p = Number(j.price);
      const prev = last; last = p;
      priceEl.textContent = fmt(p,2);
      tsEl.textContent = now();
      if(prev!==null){
        const up = p>prev; const cls = up?'ok':'warn';
        priceEl.classList.add(cls); setTimeout(()=>priceEl.classList.remove(cls),300);
      }
      statusEl.textContent='Live'; statusEl.className='ok';
    }catch(e){
      statusEl.textContent='Потеря связи — переподключение…'; statusEl.className='warn';
    }
  }

  function renderTop(rows, top){
    const list = (top && top.length) ? top : (rows||[]).slice(0,5);
    if(!list.length){ balancesWrap.innerHTML='Нет активов'; assetsCountEl.textContent='0'; usdcFreeEl.textContent='0.00'; return; }
    let usdcFree=0;
    let html = '<table><tr><th>Актив</th><th>Доступно</th><th>Заморожено</th><th>Всего</th></tr>';
    for(const r of list){
      const isBNB = r.asset==='BNB';
      if(r.asset==='USDC') usdcFree=r.free;
      html += `<tr class="${isBNB?'bnb':''}"><td>${r.asset}</td><td>${fmt(r.free,8)}</td><td>${fmt(r.locked,8)}</td><td>${fmt(r.total,8)}</td></tr>`;
    }
    html += '</table>';
    balancesWrap.innerHTML = html;
    assetsCountEl.textContent = rows.length;
    usdcFreeEl.textContent = fmt(usdcFree,2);
  }

  async function pollBalances(){
    try{
      const r = await fetch('/api/balances',{cache:'no-store'});
      const j = await r.json();
      if(!r.ok) throw new Error(j.error||('HTTP '+r.status));
      renderTop(j.rows||[], j.top||[]);
    }catch(e){
      balancesWrap.innerHTML='<span class="warn">Ошибка загрузки балансов</span>';
    }
  }

  async function feeAuto(){
    feeResult.textContent='Считаю…';
    try{
      const body = {
        symbol: pairEl.value,
        amount_usdc: Number(amountEl.value||0),
        require_bnb: requireBNBEl.checked
      };
      const r = await fetch('/api/fee_check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
      const j = await r.json();
      if(!r.ok) throw new Error(j.error||('HTTP '+r.status));

      lastFee = j;

      let msg =
        `BNB требуется: <b>${fmt(j.need_bnb,6)}</b>, доступно: <b>${fmt(j.have_bnb,6)}</b><br>`+
        `Комиссия (вход+выход) оценочно: ${fmt(j.fee_usdc,4)} USDC<br>`+
        (j.enough ? '<span class="ok">BNB достаточно</span>' : '<span class="warn">BNB не хватает</span>')+
        (j.require_block && !j.enough ? ' — вход заблокирован по настройке' : '');

      if(j.enough_usdc){
        msg += `<br><span class="ok">Средств достаточно (${fmt(j.have_usdc,2)} USDC)</span>`;
      }else{
        msg += `<br><span class="warn">Недостаточно USDC (доступно ${fmt(j.have_usdc,2)}, нужно ${fmt(j.amount_usdc,2)})</span>`;
      }

      feeResult.innerHTML = msg;

      const canCreate = j.enough_usdc && (j.enough || !j.require_block);
      for (const b of [btnCreate, btnCreateGrid]) {
        b.classList.toggle('gray', !canCreate);
        b.style.pointerEvents = canCreate ? 'auto' : 'none';
      }
      createHint.textContent = canCreate ? '' : 'Исправьте проверки выше, чтобы создать сделку.';
    }catch(e){
      feeResult.innerHTML = '<span class="warn">Ошибка проверки: '+(e.message||e)+'</span>';
      for (const b of [btnCreate, btnCreateGrid]) { b.classList.add('gray'); b.style.pointerEvents='none'; }
      createHint.textContent = 'Нет данных для создания сделки.';
    }
  }

  async function loadTrades(){
    try{
      const r=await fetch("/api/trades",{cache:"no-store"});
      const j=await r.json();
      if(!r.ok) throw new Error(j.error||("HTTP "+r.status));
      const arr=j.trades||[];
      if(!arr.length){ tradesWrap.textContent="Пока нет сделок"; return;}
      let html="<table><tr><th>ID</th><th>Статус</th><th>Пара</th><th>Сумма</th><th>Вход, $</th><th>Кол-во</th><th></th></tr>";
      for(const t of arr){
        html+=`<tr>
          <td><a href="/trade/${t.id}">#${t.id}</a></td>
          <td>${t.status}</td>
          <td>${t.symbol}</td>
          <td>${t.amount_usdc.toFixed(2)} USDC</td>
          <td>${t.entry_price.toFixed(2)}</td>
          <td>${t.qty.toFixed(8)}</td>
          <td><a href='#' data-id='${t.id}' class='btn red btn-del'>Удалить</a></td>
        </tr>`;
      }
      html+="</table>";
      tradesWrap.innerHTML=html;
      for(const a of tradesWrap.querySelectorAll(".btn-del")){
        a.addEventListener("click", async (ev)=>{
          ev.preventDefault();
          const id=Number(a.getAttribute("data-id"));
          if(!confirm("Удалить сделку #"+id+"?")) return;
          const r=await fetch("/api/trades/delete",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({id})});
          const j=await r.json();
          if(!r.ok||!j.ok){ alert("Ошибка удаления"); }
          await loadTrades();
        });
      }
    }catch(e){ tradesWrap.innerHTML="<span class='warn'>Ошибка загрузки сделок</span>"; }
  }

  function start(){
    if(timerPrice) clearInterval(timerPrice);
    if(timerBal) clearInterval(timerBal);
    pollPrice(); timerPrice=setInterval(pollPrice,500);
    pollBalances(); timerBal=setInterval(pollBalances,5000);

    feeAuto();
    pairEl.addEventListener('change', feeAuto);
    amountEl.addEventListener('input', feeAuto);
    requireBNBEl.addEventListener('change', feeAuto);
    setInterval(feeAuto, 30000);

    loadTrades();
    setInterval(loadTrades, 5000);

    btnCreate.addEventListener('click', async (ev)=>{
      ev.preventDefault();
      try{
        const body={ symbol: pairEl.value, amount_usdc: Number(amountEl.value||0), require_bnb: requireBNBEl.checked };
        const r=await fetch("/api/trades",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
        const j=await r.json();
        if(!r.ok||!j.ok){ throw new Error(j.error||("HTTP "+r.status)); }
        createHint.textContent = `Готово: сделка #${j.trade.id} создана.`;
        await loadTrades();
      }catch(e){
        createHint.textContent = 'Ошибка создания: '+(e.message||e);
      }
    });

    btnCreateGrid.addEventListener('click', async (ev)=>{
      ev.preventDefault();
      try{
        const body={ symbol: pairEl.value, amount_usdc: Number(amountEl.value||0), require_bnb: requireBNBEl.checked };
        const r=await fetch("/api/trades/grid",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
        const j=await r.json();
        if(!r.ok||!j.ok){ throw new Error(j.error||("HTTP "+r.status)); }
        const ids = (j.trades||[]).map(t=>t.id).join(', ');
        createHint.textContent = `Готово: создана сетка, сделки #${ids}.`;
        await loadTrades();
      }catch(e){
        createHint.textContent = 'Ошибка создания сетки: '+(e.message||e);
      }
    });

    btnReset.addEventListener("click", async (ev)=>{
      ev.preventDefault();
      if(!confirm("Сбросить все сделки?")) return;
      const r=await fetch("/api/reset",{method:"POST"});
      const j=await r.json();
      if(!r.ok||!j.ok){ alert("Ошибка сброса"); return;}
      await loadTrades();
    });
  }

  sel.addEventListener('change', start);
  start();
</script>
</body></html>""", mimetype="text/html")

@app.get("/assets")
def assets_page():
    return Response("""<!doctype html>
<html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Мои активы</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Arial,sans-serif;margin:24px}
  .muted{color:#666}
  .btn{display:inline-block;padding:8px 12px;border:1px solid #333;border-radius:8px;text-decoration:none;color:#111}
  table{border-collapse:collapse;width:100%} th,td{padding:8px;border-bottom:1px solid #eee;text-align:left}
  tr.bnb td{background:#fff8e1}
  input{padding:8px 10px;border:1px solid #ccc;border-radius:8px;width:240px}
</style>
</head><body>
  <h1>Мои активы</h1>
  <p><a class="btn" href="/">← На главную</a></p>

  <div style="margin:12px 0">
    <input id="q" placeholder="Поиск по тикеру (например, BNB)">
    <span class="muted">Автообновление каждые 10 сек</span>
  </div>

  <div id="wrap" class="muted">Загрузка…</div>

<script>
  const wrap = document.getElementById('wrap');
  const q = document.getElementById('q');
  let all=[], timer=null;

  function fmt(n,d=8){ return Number(n).toLocaleString('ru-RU',{minimumFractionDigits:d,maximumFractionDigits:d}); }

  function render(){
    const s=(q.value||'').trim().toUpperCase();
    const rows = s ? all.filter(r=>r.asset.includes(s)) : all;
    if(!rows.length){ wrap.innerHTML='Нет активов'; return; }
    let html = '<table><tr><th>Актив</th><th>Доступно</th><th>Заморожено</th><th>Всего</th></tr>';
    for(const r of rows){
      const isBNB = r.asset==='BNB';
      html += `<tr class="${isBNB?'bnb':''}"><td>${r.asset}</td><td>${fmt(r.free)}</td><td>${fmt(r.locked)}</td><td>${fmt(r.total)}</td></tr>`;
    }
    html += '</table>';
    wrap.innerHTML = html;
  }

  async function load(){
    try{
      const r = await fetch('/api/balances',{cache:'no-store'});
      const j = await r.json();
      all = j.rows||[];
      render();
    }catch(e){ wrap.innerHTML='<span class="warn">Ошибка загрузки</span>'; }
  }

  q.addEventListener('input', render);
  function start(){ if(timer) clearInterval(timer); load(); timer=setInterval(load, 10000); }
  start();
</script>
</body></html>""", mimetype="text/html")

@app.get("/trade/<int:tid>")
def trade_page(tid: int):
    return Response(f"""<!doctype html>
<html lang="ru"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Сделка #{tid}</title>
<style>
  body{{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,Arial,sans-serif;margin:24px}}
  .row{{display:flex;gap:12px;flex-wrap:wrap;align-items:center}}
  .price{{font-size:36px;font-weight:700}}
  .muted{{color:#666}} .ok{{color:#0a0}} .warn{{color:#b00}}
  .card{{border:1px solid #ddd;border-radius:12px;padding:16px;margin-top:16px}}
  .btn{{display:inline-block;padding:8px 12px;border:1px solid #333;border-radius:8px;text-decoration:none;color:#111}}
  .btn.red{{border-color:#b00;color:#b00}}
  table{{border-collapse:collapse}} th,td{{padding:6px 10px;border-bottom:1px solid #eee;text-align:left}}
</style>
</head><body>
  <h1>Сделка #{tid}</h1>
  <p><a class="btn" href="/">← На главную</a></p>

  <div id="err" class="warn" style="display:none"></div>

  <div class="card">
    <div class="row"><div class="price">Цена: <span id="price">—</span></div><div class="muted">время: <span id="ts">—</span></div></div>
    <div class="row">PnL: <b id="pnl">—</b> <span id="pnlp" class="muted">(—%)</span></div>
  </div>

  <div class="card">
    <table>
      <tr><th>Пара</th><td id="sym">—</td></tr>
      <tr><th>Статус</th><td id="st">—</td></tr>
      <tr><th>Количество</th><td id="qty">—</td></tr>
      <tr><th>Вход, $</th><td id="entry">—</td></tr>
      <tr><th>Потрачено, USDC</th><td id="spent">—</td></tr>
      <tr><th>High watermark</th><td id="hwm">—</td></tr>
      <tr><th>Создана</th><td id="created">—</td></tr>
    </table>
  </div>

  <div class="card">
    <a href="#" id="btnDel" class="btn red">Удалить сделку</a>
    <span id="actMsg" class="muted"></span>
  </div>

<script>
const tid = """ + str(tid) + """;
const priceEl = document.getElementById('price');
const tsEl = document.getElementById('ts');
const pnlEl = document.getElementById('pnl');
const pnlpEl = document.getElementById('pnlp');
const errEl = document.getElementById('err');

const symEl = document.getElementById('sym');
const stEl = document.getElementById('st');
const qtyEl = document.getElementById('qty');
const entryEl = document.getElementById('entry');
const spentEl = document.getElementById('spent');
const hwmEl = document.getElementById('hwm');
const createdEl = document.getElementById('created');

const btnDel = document.getElementById('btnDel');
const actMsg = document.getElementById('actMsg');

let trade=null, timer=null;

function fmt(n,d=2){ return Number(n).toLocaleString('ru-RU',{minimumFractionDigits:d,maximumFractionDigits:d}); }
function tsToStr(ts){ return new Date(ts*1000).toLocaleString('ru-RU'); }

async function loadTrade(){
  const r = await fetch('/api/trade/'+tid, {cache:'no-store'});
  if(!r.ok){
    errEl.style.display='block';
    errEl.textContent='Сделка не найдена';
    return false;
  }
  trade = await r.json();
  symEl.textContent = trade.symbol;
  stEl.textContent = trade.status;
  qtyEl.textContent = fmt(trade.qty, 8);
  entryEl.textContent = fmt(trade.entry_price, 2);
  spentEl.textContent = fmt(trade.spent_usdc, 2);
  hwmEl.textContent = fmt(trade.high_watermark, 2);
  createdEl.textContent = tsToStr(trade.created_at);
  return true;
}

async function pollPrice(){
  try{
    const r = await fetch('/api/price?symbol='+encodeURIComponent(trade.symbol), {cache:'no-store'});
    const j = await r.json();
    if(!r.ok) throw new Error(j.error||('HTTP '+r.status));
    const p = Number(j.price);
    priceEl.textContent = fmt(p,2);
    tsEl.textContent = new Date().toLocaleTimeString('ru-RU');

    const curVal = p * trade.qty;
    const pnl = curVal - trade.spent_usdc;
    const pnlp = (pnl / trade.spent_usdc) * 100.0;

    pnlEl.textContent = (pnl>=0?'+':'') + fmt(pnl,2) + ' USDC';
    pnlEl.className = pnl>=0 ? 'ok' : 'warn';
    pnlpEl.textContent = '(' + (pnlp>=0?'+':'') + fmt(pnlp,2) + '%)';

  }catch(e){
    priceEl.textContent='—'; pnlEl.textContent='—'; pnlpEl.textContent='(—%)';
  }
}

btnDel.addEventListener('click', async (ev)=>{
  ev.preventDefault();
  if(!confirm('Удалить сделку #'+tid+'?')) return;
  try{
    const r=await fetch('/api/trades/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:tid})});
    const j=await r.json();
    if(!r.ok||!j.ok) throw new Error('Ошибка удаления');
    actMsg.textContent='Удалено. Возврат на главную…';
    setTimeout(()=>{ window.location.href='/'; },800);
  }catch(e){
    actMsg.textContent='Ошибка: '+(e.message||e);
  }
});

(async function(){
  const ok = await loadTrade();
  if(!ok) return;
  pollPrice();
  timer = setInterval(pollPrice, 500);
})();
</script>
</body></html>""", mimetype="text/html")

# ---------- APIs ----------

@app.get("/api/price")
def api_price():
    symbol = request.args.get("symbol", DEFAULT_SYMBOL).upper()
    try:
        price = price_public(symbol)
        return jsonify({"symbol": symbol, "price": price, "ts": int(time.time())})
    except Exception as e:
        return jsonify({"error": str(e), "symbol": symbol}), 500

@app.get("/api/balances")
def api_balances():
    try:
        rows = fetch_balances()
        mp = {r["asset"]: r for r in rows}
        top = []
        for a in TOP_ASSETS:
            top.append(mp.get(a, {"asset": a, "free": 0.0, "locked": 0.0, "total": 0.0}))
        return jsonify({"rows": rows, "top": top, "ts": int(time.time())})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/api/fee_check")
def api_fee_check():
    try:
        body = request.get_json(force=True)
        symbol = (body.get("symbol") or DEFAULT_SYMBOL).upper()
        amount_usdc = float(body.get("amount_usdc") or 0.0)
        require_block = bool(body.get("require_bnb", True))

        if amount_usdc <= 0:
            return jsonify({"error":"Сумма должна быть > 0"}), 400

        rows = fetch_balances()
        have_bnb = 0.0
        have_usdc = 0.0
        for r in rows:
            if r["asset"] == "BNB":
                have_bnb = float(r["free"] or 0.0)
            if r["asset"] == "USDC":
                have_usdc = float(r["free"] or 0.0)

        fee_rate = FEE_RATE_BNB
        fee_usdc = amount_usdc * fee_rate * 2.0
        bnb_price = price_public("BNBUSDC")
        need_bnb = (fee_usdc / bnb_price) * BNB_SAFETY

        enough = have_bnb >= need_bnb
        enough_usdc = have_usdc >= amount_usdc

        return jsonify({
            "symbol": symbol,
            "amount_usdc": amount_usdc,
            "fee_rate_used": fee_rate,
            "fee_usdc": round(fee_usdc, 6),
            "bnb_price": round(bnb_price, 6),
            "need_bnb": round(need_bnb, 6),
            "have_bnb": round(have_bnb, 6),
            "enough": enough,
            "require_block": require_block,
            "have_usdc": round(have_usdc, 2),
            "enough_usdc": enough_usdc,
            "ts": int(time.time())
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ---------- Trades APIs ----------

@app.get("/api/trades")
def api_trades_list():
    try:
        return jsonify({"trades": list_trades(), "ts": int(time.time())})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.get("/api/trade/<int:tid>")
def api_trade_one(tid: int):
    t = get_trade(tid)
    if not t:
        return jsonify({"error": "not found"}), 404
    return jsonify(t)

@app.post("/api/trades")
def api_trades_create():
    try:
        body = request.get_json(force=True)
        symbol = (body.get("symbol") or DEFAULT_SYMBOL).upper()
        amount_usdc = float(body.get("amount_usdc") or 0.0)
        require_bnb = bool(body.get("require_bnb", True))
        if amount_usdc <= 0:
            return jsonify({"error": "Сумма должна быть > 0"}), 400

        rows = fetch_balances()
        have_usdc = 0.0
        have_bnb = 0.0
        for r in rows:
            if r["asset"] == "USDC": have_usdc = float(r["free"] or 0.0)
            if r["asset"] == "BNB":  have_bnb  = float(r["free"] or 0.0)
        if have_usdc < amount_usdc:
            return jsonify({"error": f"Недостаточно USDC: доступно {have_usdc}, нужно {amount_usdc}"}), 400

        fee_usdc = amount_usdc * FEE_RATE_BNB * 2.0
        bnb_price = price_public("BNBUSDC")
        need_bnb = (fee_usdc / bnb_price) * BNB_SAFETY
        if require_bnb and have_bnb < need_bnb:
            return jsonify({"error": f"Недостаточно BNB для комиссий: доступно {have_bnb}, нужно {need_bnb}"}), 400

        entry_price = price_public(symbol)
        qty = (amount_usdc / entry_price) * (1 - FEE_RATE_BNB)
        spent = entry_price * qty * (1 + FEE_RATE_BNB)
        trade = add_trade(symbol, amount_usdc, round(entry_price, 2), round(qty, 8), round(spent, 2))
        return jsonify({"ok": True, "trade": trade})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/api/trades/grid")
def api_trades_grid():
    """
    Создаёт 3 сделки: 30%, 30%, 40% от суммы.
    Проверяет наличие USDC и BNB по общей сумме.
    """
    try:
        body = request.get_json(force=True)
        symbol = (body.get("symbol") or DEFAULT_SYMBOL).upper()
        total_usdc = float(body.get("amount_usdc") or 0.0)
        require_bnb = bool(body.get("require_bnb", True))
        if total_usdc <= 0:
            return jsonify({"error": "Сумма должна быть > 0"}), 400

        rows = fetch_balances()
        have_usdc = 0.0
        have_bnb = 0.0
        for r in rows:
            if r["asset"] == "USDC": have_usdc = float(r["free"] or 0.0)
            if r["asset"] == "BNB":  have_bnb  = float(r["free"] or 0.0)

        if have_usdc < total_usdc:
            return jsonify({"error": f"Недостаточно USDC: доступно {have_usdc}, нужно {total_usdc}"}), 400

        fee_usdc = total_usdc * FEE_RATE_BNB * 2.0
        bnb_price = price_public("BNBUSDC")
        need_bnb = (fee_usdc / bnb_price) * BNB_SAFETY
        if require_bnb and have_bnb < need_bnb:
            return jsonify({"error": f"Недостаточно BNB для комиссий: доступно {have_bnb}, нужно {need_bnb}"}), 400

        parts = [0.30, 0.30, 0.40]
        entry_price = price_public(symbol)
        out = []
        for p in parts:
            amt = round(total_usdc * p, 2)
            qty = (amt / entry_price) * (1 - FEE_RATE_BNB)
            spent = entry_price * qty * (1 + FEE_RATE_BNB)
            t = add_trade(symbol, amt, round(entry_price, 2), round(qty, 8), round(spent, 2))
            out.append(t)

        return jsonify({"ok": True, "trades": out})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/api/trades/delete")
def api_trades_delete():
    try:
        body = request.get_json(force=True)
        trade_id = int(body.get("id"))
        ok = delete_trade(trade_id)
        return jsonify({"ok": ok})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.post("/api/reset")
def api_reset():
    try:
        reset_all()
        return jsonify({"ok": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
